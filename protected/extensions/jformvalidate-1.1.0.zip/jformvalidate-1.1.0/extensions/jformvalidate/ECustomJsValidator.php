<?php
class ECustomJsValidator extends CValidator {
	
	public $rules;
	public $messages;
	
	/**
	 * @param CModel the object being validated
	 * @param string the attribute being validated
	 */
	protected function validateAttribute($object,$attribute){
		$valid=true;
	}	
} 
?>
