<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('chkin_id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->chkin_id), array('view', 'id'=>$data->chkin_id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('guest_id')); ?>:</b>
	<?php echo CHtml::encode($data->guest_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('reservation_id')); ?>:</b>
	<?php echo CHtml::encode($data->reservation_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('chkin_date')); ?>:</b>
	<?php echo CHtml::encode($data->chkin_date); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('chkout_date')); ?>:</b>
	<?php echo CHtml::encode($data->chkout_date); ?>
	<br />	

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('drop_service')); ?>:</b>
	<?php echo CHtml::encode($data->drop_service); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('flight_name')); ?>:</b>
	<?php echo CHtml::encode($data->flight_name); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('flight_time')); ?>:</b>
	<?php echo CHtml::encode($data->flight_time); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('total_days')); ?>:</b>
	<?php echo CHtml::encode($data->total_days); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('room_id')); ?>:</b>
	<?php echo CHtml::encode($data->room_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('room_type')); ?>:</b>
	<?php echo CHtml::encode($data->room_type); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('room_name')); ?>:</b>
	<?php echo CHtml::encode($data->room_name); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('guest_company_id')); ?>:</b>
	<?php echo CHtml::encode($data->guest_company_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('rate_type')); ?>:</b>
	<?php echo CHtml::encode($data->rate_type); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('total_person')); ?>:</b>
	<?php echo CHtml::encode($data->total_person); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('total_charges')); ?>:</b>
	<?php echo CHtml::encode($data->total_charges); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('amount_paid')); ?>:</b>
	<?php echo CHtml::encode($data->amount_paid); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('chkout_status')); ?>:</b>
	<?php echo CHtml::encode($data->chkout_status); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('chkin_user_id')); ?>:</b>
	<?php echo CHtml::encode($data->chkin_user_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('chkout_user_id')); ?>:</b>
	<?php echo CHtml::encode($data->chkout_user_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('guest_status_id')); ?>:</b>
	<?php echo CHtml::encode($data->guest_status_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('chkin_id')); ?>:</b>
	<?php echo CHtml::encode($data->chkin_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('sale_person_id')); ?>:</b>
	<?php echo CHtml::encode($data->sale_person_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('comming_from')); ?>:</b>
	<?php echo CHtml::encode($data->comming_from); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('next_destination')); ?>:</b>
	<?php echo CHtml::encode($data->next_destination); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('newspaper_id')); ?>:</b>
	<?php echo CHtml::encode($data->newspaper_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('rate')); ?>:</b>
	<?php echo CHtml::encode($data->rate); ?>
	<br />


	<b><?php echo CHtml::encode($data->getAttributeLabel('gst')); ?>:</b>
	<?php echo CHtml::encode($data->gst); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('bed_tax')); ?>:</b>
	<?php echo CHtml::encode($data->bed_tax); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('branch_id')); ?>:</b>
	<?php echo CHtml::encode($data->branch_id); ?>
	<br />

	*/ ?>

</div>