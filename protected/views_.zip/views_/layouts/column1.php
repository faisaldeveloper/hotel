<?php $this->beginContent('//layouts/main'); ?>
<div class="container">
	<div id="content" style="min-height:300px">
		<?php echo $content; ?>
	</div><!-- content -->
</div>
<?php $this->endContent(); ?>