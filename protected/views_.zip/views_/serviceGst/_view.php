<div class="view">

	

	<b><?php echo CHtml::encode($data->getAttributeLabel('gst_service_id')); ?>:</b>
	<?php echo CHtml::encode($data->gstService->service_description); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('gst_percent')); ?>:</b>
	<?php echo CHtml::encode($data->gst_percent); ?>
	<br />

	


</div>